# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyll_json_errors', 'pyll_json_errors.contrib']

package_data = \
{'': ['*']}

extras_require = \
{'all': ['Flask>=1.1.2,<2.0.0',
         'marshmallow>=3.7.0,<4.0.0',
         'djangorestframework>=3.0.0,<4.0.0',
         'werkzeug>=1.0.0,<2.0.0'],
 'flask': ['Flask>=1.1.2,<2.0.0', 'werkzeug>=1.0.0,<2.0.0'],
 'marshmallow': ['marshmallow>=3.7.0,<4.0.0'],
 'rest_framework': ['djangorestframework>=3.0.0,<4.0.0',
                    'werkzeug>=1.0.0,<2.0.0']}

setup_kwargs = {
    'name': 'pyll-json-errors',
    'version': '0.2.2',
    'description': 'Various helpers to transform popular Python library errors into LeafLink flavored JSON API errors.',
    'long_description': '# pyll-json-errors\n\nPython library to implement LeafLink flavored JSON API errors in HTTP APIs.\n\n---\n\n[![CircleCI](https://circleci.com/gh/LeafLink/pyll-json-errors.svg?style=svg&circle-token=70111963b87fa2b476fece5740320b4dc464ad11)](https://circleci.com/gh/LeafLink/pyll-json-errors)\n[![codecov](https://codecov.io/gh/LeafLink/pyll-json-errors/branch/master/graph/badge.svg?token=ICZFRWIZAC)](https://codecov.io/gh/LeafLink/pyll-json-errors)\n\n> It\'s pronounced "pill".\n\n- [Package Documentation](#package-documentation)\n- [Requirements](#requirements)\n- [Library Documentation](#library-documentation)\n- [Example and Driver Applications](#example-and-driver-applications)\n  * [Django REST Framework](#django-rest-framework)\n  * [Flask Driver](#flask-driver)\n  * [Marshmallow Driver](#marshmallow-driver)\n- [Contributing](#contributing)\n\n\n## Package Documentation\n\nSee https://pyll-dev-docs.leaflink.com/stable/index.html for `pyll-json-errors` package documentation.\n\n\n## Requirements\n* Python 3.6 or higher\n\n\n## Library Documentation\nSee the library\'s integration docs [here](https://pyll-dev-docs.leaflink.com/stable/index.html).\n\n\n## Example and Driver Applications\nVarious example and driver applications can be found in `./drivers`. Use these to test integrations\nwith various Python libraries.\n\n### Django REST Framework\nA basic DRF application for integration testing can be started by running: `. ./bin/drf-driver.sh`\n\n### Flask Driver\nA basic Flask application for integration testing can be started by running: `. ./bin/flask-driver.sh`\n\n### Marshmallow Driver\nBasic Marshmallow schema and validation example. Can be ran via: `. ./bin/marshmallow-driver.sh`\n\n\n## Contributing\nFor guidance of on setting up a development environment and contributing to Pyll JSON Errors see our\n[contributing](https://github.com/LeafLink/pyll-json-errors/blob/master/CONTRIBUTING.md) doc.\n',
    'author': 'LeafLink Engineering',
    'author_email': 'engineerin@leaflink.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/LeafLink/pyll-json-errors',
    'packages': packages,
    'package_data': package_data,
    'extras_require': extras_require,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
